# Exame SAWM

Aluno: Dante Marinho
ME: 83672

# DB

mysql -uSAWMDBUser -psawmgarantias

# Files implementados
- connection.js
- dbFunctions.js
- routes/garantias.js
- public/index.html

# Files alterados
- package.json
- app.js

# Notas

01. A questão 4 (frontend) está respondida e pode ser executada no ficheiro `public/index.html`
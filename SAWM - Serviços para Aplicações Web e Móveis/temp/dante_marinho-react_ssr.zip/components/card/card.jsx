import React from 'react'

const Card = ({id, category, url, target, date, title, slug, activeMenuItem}) => (
    <div key={id} className={`post bg-white result__single `} data-filter={category}
         data-page="1" hidden={!(activeMenuItem == category || activeMenuItem == 'All')}>
        <a href={url} className="" target={target}>
            <span className="label label--small text-orange mr-2">{category}</span>
            <span className="label label--small text-capitalize font-medium">{date}</span>
            <h4 className="mt-2">{title}</h4>
            <p className="small text-bluegrey result__single-url">
                {slug}
            </p>
        </a>
    </div>
)

export default Card
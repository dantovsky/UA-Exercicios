import React from 'react'

const Counting = ({numPosts, queryApplyed}) => (
    <p className="mb-2">
        <span className="label font-medium result-count" hidden={numPosts === 0}>
            Showing {numPosts} results for "{queryApplyed}"
        </span>
    </p>

)

export default Counting
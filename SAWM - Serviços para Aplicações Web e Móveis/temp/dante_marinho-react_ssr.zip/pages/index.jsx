import React, { useState } from "react";
import "../styles.scss";
import EmptyResult from '../components/emptyResult/emptyResult'
import Couting from '../components/counting/counting'
import Card from '../components/card/card'
import MenuItem from "../components/menuItem/menuItem";
import Form from "../components/form/form";

/**
 * Talkdesk Challenge - React SSR GLobal Search
 * Developer: Dante Ferreira Marinho | dantecnia@hotmail.com
 */

const App = () => {
    const [query, setQuery] = useState('')
    const [queryApplyed, setQueryApplyed] = useState('')
    const [resultPosts, setResultPosts] = useState([])
    const [activeMenuItem, setActiveMenuItem] = useState('All')

    // Set the active menu
    const handleActive = (menuItem) => {
        setActiveMenuItem(menuItem)
    }

    // Get the menu filter dinamically
    const getListMenu = () => {

        // Get distinct menu names present in result search
        const menuFinded = [...new Set(resultPosts.map(({category}) => category))].sort()
        const index = menuFinded.indexOf('All')
        if (index > -1) {
            menuFinded.splice(index, 1)
        }

        const menuItems = menuFinded.map(item => <MenuItem item={item} activeMenuItem={activeMenuItem} handleActive={handleActive} />)
        const allMenuItem = <MenuItem item={'All'} activeMenuItem={activeMenuItem} handleActive={handleActive} />
        
        if (menuFinded.length > 1) {
            menuItems.unshift(allMenuItem)
        }

        return menuItems 
    }

    // Get data from endpoint
    const searchPosts = e => {
        e.preventDefault()
        try {
            fetch("https://www.talkdesk.com/wp-json/external/globalsearch")
                .then(res => res.json())
                .then(res => {
                    if (!query.length) {
                        setResultPosts([])
                    } else {
                        setResultPosts(res.posts.filter(post => post.title.toLowerCase().indexOf(query.toLowerCase().trim()) != -1))
                    }
                    setQueryApplyed(query)
                    return resultPosts.length
                })
        } catch(err) {
            console.error(err)
        }        
    }

    // List posts in Card components
    const showPostslist = () => {
        return resultPosts.map(post =>
            <Card id={post.id} category={post.category} url={post.url} target={post.target}
                  date={post.date} title={post.title} slug={post.slug} activeMenuItem={activeMenuItem} />)
    }

    return (
        <div className="app container">
            <div className="search">
                <Form query={query} setQuery={setQuery} searchPosts={searchPosts} />
            </div>
            <div className="content">
                <div className="menu-filter" data-section="Filters">
                    <div id="search__categories" className="mb-4">
                        <ul className="mb-3">
                            {getListMenu()}
                        </ul>
                    </div>
                </div>
                <div className="list">
                    <Couting numPosts={resultPosts.length} queryApplyed={queryApplyed} />
                    <div id="list__results" className="posts">
                        {resultPosts.length > 0 ? showPostslist() : <EmptyResult />}    
                    </div> 
                </div>           
            </div>
        </div>
    );
};

export default App;
// import React, { useState } from "react";
// import "../styles.scss";

const MyComponent = () => {

    return (
        <div>
        Oiii
        </div>
    );
};

export default MyComponent;